# AutoMOD

AutoMOD is the official MODification installer for phpBB 3.0.

http://www.phpbb.com/mods/automod/

## Patches

Do you have an improvement? Did you fix a bug? Fork our GitHub repo, make your changes in a separate branch and send a pull request.

## Bug Tracker

If you find a bug, please submit it to the [MOD Team Tools](https://www.phpbb.com/bugs/modteamtools/) bug tracker on phpBB.com.
